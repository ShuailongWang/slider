//
//  SEFilterKnob.h
//  RGfzzd
//
//  Created by admin on 16/12/13.
//  Copyright © 2016年 北京奥泰瑞格科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SEFilterKnob : UIButton
@property(nonatomic, strong) UIColor *handlerColor;
@end
